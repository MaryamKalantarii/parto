
declare module "*.css";
